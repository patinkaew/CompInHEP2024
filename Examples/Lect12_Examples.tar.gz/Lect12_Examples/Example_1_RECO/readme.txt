scram p CMSSW CMSSW_14_0_4
cd CMSSW_14_0_4/src
cmsenv

git cms-addpkg Configuration/Generator
scram b -j 16

# Starting from the GEN-fragment, and creating a SIM file, 10 events

cmsDriver.py Configuration/Generator/python/H200ZZ4L_13TeV_TuneCUETP8M1_cfi.py --eventcontent FEVTDEBUG --datatier GEN-SIM --conditions auto:run3_mc_GRun --step GEN,SIM --era Run3_2023 --no_exec --fileout file:step1.root

cmsRun TTbar_13TeV_TuneCUETP8M1_cfi_py_GEN_SIM.py

# SIM->RAW, all events from the input file (-n -1)
cmsDriver.py step2 --conditions auto:run3_mc_GRun -n -1 --eventcontent FEVTDEBUGHLT -s DIGI,L1,DIGI2RAW,HLT --datatier GEN-SIM-DIGI-RAW --no_exec --era Run3_2023 --filein file:step1.root --fileout file:step2.root

cmsRun step2_DIGI_L1_DIGI2RAW_HLT.py

# RAW->RECO, all events from the input file (-n -1)
cmsDriver.py step3 --conditions auto:run3_mc_GRun -n -1 --eventcontent FEVTDEBUGHLT -s RAW2DIGI,L1Reco,RECO --datatier GEN-SIM-RECO --no_exec --era Run3_2023 --filein file:step2.root --fileout file:step3.root

cmsRun step3_RAW2DIGI_L1Reco_RECO.py
