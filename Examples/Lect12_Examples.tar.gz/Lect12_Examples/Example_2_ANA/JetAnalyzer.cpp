#include "FWCore/MessageLogger/interface/MessageLogger.h"
#include "FWCore/Framework/interface/one/EDAnalyzer.h"

#include "FWCore/Framework/interface/EventSetup.h"
#include "FWCore/Framework/interface/ESHandle.h"
#include "FWCore/Framework/interface/MakerMacros.h"

#include "FWCore/ParameterSet/interface/ParameterSet.h"

#include "FWCore/Framework/interface/Event.h"


#include "DataFormats/JetReco/interface/PFJet.h"
#include "DataFormats/JetReco/interface/PFJetCollection.h"


using namespace reco;

#include <iostream>
using namespace std;

class JetAnalyzer : public edm::one::EDAnalyzer<> {
    public:
	JetAnalyzer(const edm::ParameterSet&);
	~JetAnalyzer();

	void beginJob();
	void analyze( const edm::Event&, const edm::EventSetup&);
	void endJob();

    private:
  	edm::EDGetTokenT<reco::PFJetCollection> jetToken;
};

JetAnalyzer::JetAnalyzer(const edm::ParameterSet& iConfig) :
jetToken(consumes<reco::PFJetCollection>(iConfig.getParameter<edm::InputTag>("jetSrc")))
{}

JetAnalyzer::~JetAnalyzer() {}

void JetAnalyzer::beginJob(){}
void JetAnalyzer::analyze( const edm::Event& iEvent, const edm::EventSetup& iSetup){

    // How to access RECO collections, using jets as an example. 
    // We analyze jets in a collection named recoPFJets_ak4PFJets__RECO

    edm::Handle<reco::PFJetCollection> jetHandle;
    iEvent.getByToken(jetToken, jetHandle);

    if(jetHandle.isValid()){
      std::cout << "Number of jets in the event " << jetHandle->size() << std::endl;
      for (reco::PFJetCollection::const_iterator i=jetHandle->begin(); i != jetHandle->end(); i++ ) {
	std::cout << "    jet pt " << i->pt() << std::endl;
      }
    }
}

void JetAnalyzer::endJob(){}

DEFINE_FWK_MODULE(JetAnalyzer);
