import FWCore.ParameterSet.Config as cms

process = cms.Process("MyANA")

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(-1)
)

process.source = cms.Source("PoolSource",
    fileNames = cms.untracked.vstring(
	"file:step3.root"
    )
)

process.analysis = cms.EDAnalyzer('JetAnalyzer',
    jetSrc = cms.InputTag("ak4PFJets")
)

# module execution
process.runEDAna = cms.Path(process.analysis)

#process.output = cms.OutputModule("PoolOutputModule",
#    outputCommands = cms.untracked.vstring(
#        "drop *",
#        "keep edmHepMCProduct_*_*_*"
#    ),
#    fileName = cms.untracked.string("CMSSW_Data.root")
#)
#process.out_step = cms.EndPath(process.output)
