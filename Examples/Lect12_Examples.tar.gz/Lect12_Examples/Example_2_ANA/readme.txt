scram p CMSSW CMSSW_14_0_4
cd CMSSW_14_0_4/src
mkdir -p TestAnalyzers/Analysis/test
cp ../../JetAnalyzer.cpp ../../jetAnalyzer_cfg.py ../../BuildFile.xml TestAnalyzers/Analysis/test
cd TestAnalyzers/Analysis/test
scram b -j 16
cmsenv

copy the input file step3.root here

cmsRun jetAnalyzer_cfg.py
