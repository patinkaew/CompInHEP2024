# Virtual environment
python -m venv VirtualTestEnvironment
source VirtualTestEnvironment/bin/activate
pip install wheel
pip install xrootd==5.4.2
pip install numpy==1.23
pip install coffea
