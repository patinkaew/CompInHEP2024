# Singularity container, build image
singularity build coffea.sif docker://coffeateam/coffea-dask

# Not enough space on /tmp
export SINGULARITY_TMPDIR=/media/Duo/Zb/test/

# Packages missing, open singularity interactively to install the missing modules
singularity shell coffea.sif
pip install dask_histogram
pip install dask-awkward

pip list coffea

pip install coffea==2024.4.0
