#!/usr/bin/env python

import datetime

import ROOT

ROOT.ROOT.EnableImplicitMT()

def main():

    df = ROOT.RDataFrame("Events", "DYJetsToLL_M_50_2022.root")
    df = df.Filter("nMuon == 2", "Events with exactly two muons")
    df = df.Filter("Muon_charge[0] + Muon_charge[1] == 0", "Muons with opposite charge")

    df_dimuon = df.Define("Dimuon_mass", "InvariantMass(Muon_pt, Muon_eta, Muon_phi, Muon_mass)")
    histo = df_dimuon.Histo1D(("h_mass", ";x-axis;y-axis", 200, 0, 200), "Dimuon_mass")

    fOUT = ROOT.TFile.Open("output.root","RECREATE")

    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    now = datetime.datetime.now()
    m = "produced: %s %s"%(days[now.weekday()],now)
    timestamp = ROOT.TNamed(m,"")
    timestamp.Write()

    histo.Write()

    fOUT.Close()

if __name__ == "__main__":
    main()

