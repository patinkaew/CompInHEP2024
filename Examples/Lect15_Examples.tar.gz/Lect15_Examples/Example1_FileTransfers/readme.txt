# Looking at my SE user space
arcls https://hip-cms-se.csc.fi:2880/store/user/slehti

Copying a local file there
arccp file://$PWD/test.root https://hip-cms-se.csc.fi:2880/store/user/slehti/test.root
arcls https://hip-cms-se.csc.fi:2880/store/user/slehti


# Removing the file test.root from the SE
arcrm https://hip-cms-se.csc.fi:2880/store/user/slehti/test.root
arcls https://hip-cms-se.csc.fi:2880/store/user/slehti

