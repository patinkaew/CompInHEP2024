Assuming .globus is ok..

arcproxy -S <your-VO>

# xrsl job description language
arcsub -c kale-cms.grid.helsinki.fi test.xrsl
arcstat gsiftp://kale-cms.grid.helsinki.fi:2811/jobs/...
arcget gsiftp://kale-cms.grid.helsinki.fi:2811/jobs/...

