#!/usr/bin/env python

import os
import re
import sys

def main():
    libsneeded = (execute("root-config --glibs"))[0].split()
    #print(libsneeded)

    rootsys = os.environ['ROOTSYS']
    libpath = os.path.join(rootsys,"lib")
    alllibs = execute("ls %s"%libpath)

    lib_re = re.compile("^-l(?P<lib>([A-Z]\S+$))")
    shared_re = re.compile("^lib\S+\.so$")

    # ROOT libs
    libs = []
    for lib in libsneeded:
        match = lib_re.search(lib)
        if match:
            libName = match.group("lib")
            for cand in alllibs:
                shared_match = shared_re.search(cand)
                if shared_match and cand.find(libName) > 0:
                    libs.append(cand)

    # System libs
    #libCore.so => /home/slehti/public/Programs/root-6.26.00_build/lib/libCore.so (0x00007fc725095000)
    syslib_re = re.compile("(?P<name>\S+)\s+\S+\s+(?P<lib>\S+)")
    syslibs = execute("ldd writing")
    slibs = []
    for lib in syslibs:
        match = syslib_re.search(lib)
        if match:
            libName = match.group("lib")
            if match.group("name") not in libs:
                slibs.append(libName)

    if not os.path.isdir("libs"):
        os.system("mkdir libs")
        for lib in libs:
            lib = os.path.join(libpath,lib)
            os.system("cp %s libs"%lib)
        for lib in slibs:
            os.system("cp %s libs"%lib)

        llibs = execute("ls libs")
        for lib in llibs:
            ndots = lib.count('.')
            if ndots > 2:
                print("ndots",lib,ndots)
                linkname = lib[:lib.find('.',lib.find('.',lib.find('.')+1)+1)]
                cmd = "cd libs && ln -s %s %s"%(lib,linkname)
                print(cmd)
                os.system(cmd)
        os.system("tar cf libs.tar libs")
        os.system("gzip libs.tar")
        #os.system("rm -rf libs")
        
def execute(cmd):
    f = os.popen(cmd)
    ret=[]
    for line in f:
        ret.append(line.replace("\n", ""))
    f.close()
    return ret

if __name__ == "__main__":
    main()
