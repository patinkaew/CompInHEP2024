#include "TTree.h"
#include "TFile.h"
#include "TRandom.h"

#include <iostream>

using namespace std;

int main(){
  // Initialize random number generator with a seed
  gRandom->SetSeed(123454321);
  // Define the number of "events"
  int N = 1000;

  // Open new root file on disk
  TFile* myRootFile = new TFile("tree.root","RECREATE");
  if (!myRootFile) {
    cout << "Error: cannot open file tree.root!" << endl;
    return 0;
  }

  // Open root tree
  TTree* myRootTree = new TTree("ExampleTree","tree");
  if (!myRootTree) {
    cout << "Error: cannot create a root tree!" << endl;
    return 0;
  }
  
  // Create a branch for storing the values from the memory adress
  // of the variable f
  float f;
  myRootTree->Branch("gaussian",&f,"value/F");
  
  // Fill random variables of default gaussian distribution to the root tree 
  for(int i = 0; i < N; i++){
    f = gRandom->Gaus(); // mean=0, sigma=1
    myRootTree->Fill();
  }

  // Write root tree, delete it from memory, and close it
  myRootTree->Write();
  myRootTree->Delete();
  myRootFile->Close();

  return 0;
}
