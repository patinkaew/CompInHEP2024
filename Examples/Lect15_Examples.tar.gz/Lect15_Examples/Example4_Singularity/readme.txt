Test: singularity run -i -B ${PWD}:/work root.sif bash -c /work/job.sh

singularity build root.sif docker://rootproject/root:6.26.06-conda
singularity build root.sif docker://rootproject/root:6.26.00-ubuntu20.04

arcproxy -S <your-VO>

arcsub -c kale-cms.grid.helsinki.fi test.xrsl
