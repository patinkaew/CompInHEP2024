#ifndef MyLib_h
#define MyLib_h

#include <string>

class MyLib{
 public:
  MyLib();
  ~MyLib();

  void print(std::string message);
};
#endif
