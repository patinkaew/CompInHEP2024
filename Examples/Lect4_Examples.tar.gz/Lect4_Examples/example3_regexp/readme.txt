Compile
	make
Run
	example4.3
