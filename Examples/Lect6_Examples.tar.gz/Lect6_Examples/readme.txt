Execute typing
root <script file>
