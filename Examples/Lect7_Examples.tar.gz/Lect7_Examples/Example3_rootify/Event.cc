#include "Event.h"

ClassImp(Event)

Event::Event() {}
Event::~Event() {}
