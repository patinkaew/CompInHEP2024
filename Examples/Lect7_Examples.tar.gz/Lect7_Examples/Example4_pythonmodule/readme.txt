http://en.wikibooks.org/wiki/Python_Programming/Extending_with_C
http://docs.python.org/extending/extending.html
http://docs.python.org/extending/building.html#building
http://docs.python.org/install/index.html

python setup.py build
python setup.py install --home=$HOME/python

